#include "sim-basics.h"

typedef uint32_t sim_cia;

#include "sim-base.h"

struct sim_state {
  sim_state_base base;
};
